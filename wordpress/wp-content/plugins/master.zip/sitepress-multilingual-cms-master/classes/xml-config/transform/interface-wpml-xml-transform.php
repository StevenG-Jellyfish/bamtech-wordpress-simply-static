<?php

/**
 * @author OnTheGo Systems
 */
interface WPML_XML_Transform {
	public function get( $source, $get_attributes = true );
}